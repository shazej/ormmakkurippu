import { ActivityRepository } from '../features/activity/activity.repository.js';

const activityRepo = new ActivityRepository();

/**
 * Logs an audit event to the 'audit_logs' collection.
 * @param {object} actor - user object { uid, email, role }
 * @param {string} action - action name (e.g., 'CREATE_TASK', 'DELETE_TASK')
 * @param {string} targetType - e.g., 'task', 'user'
 * @param {string} targetId - ID of the target object
 * @param {object} details - Additional details (diff, reason, etc.)
 */
export const logAudit = async (actor, action, targetType, targetId, details = {}) => {
    try {
        const auditEntry = {
            actorUid: actor?.uid || 'system',
            actorEmail: actor?.email || 'unknown',
            actorRole: actor?.role || 'unknown',
            action,
            targetType,
            targetId,
            details,
            ip: details.ip || 'unknown',
            userAgent: details.userAgent || 'unknown'
        };

        if (process.env.E2E_TEST_MODE === 'true') {
            console.log('🛡️ [Audit (Demo)]:', action, targetType, targetId);
        }

        await activityRepo.create(auditEntry);

    } catch (error) {
        console.error('❌ Failed to log audit event:', error);
    }
};

